import { Injectable } from '@angular/core';
import { Cart } from 'src/app/shared/models/cart';
import { CartItem } from 'src/app/shared/models/cartItem';
import { Medicine } from 'src/app/shared/models/medicine';
import { adminMedicine } from 'src/app/shared/models/adminMedicine';

@Injectable({
  providedIn: 'root'
})
export class CartService {
  private cart: Cart = new Cart();
  constructor() { }


  addToCart(medicine: Medicine): void {
    console.log(medicine, "Medicine from add to cart.", medicine.medicineId);
    let cartItem = this.cart.items.find(item => item.medicine.medicineId === medicine.medicineId);

    if (cartItem) {
      this.changeQuantity(medicine.medicineId, cartItem.quantity + 1);
      return;
    }

    this.cart.items.push(new CartItem(medicine));
    console.log(this.cart.items, "cart items only.");
  }

  removeFromCart(medicineId: number): void {
    this.cart.items = this.cart.items.filter(item => item.medicine.medicineId != medicineId);
  }

  changeQuantity(medicineId: number, quantity: number) {
    let cartItem = this.cart.items.find(item => item.medicine.medicineId === medicineId);
    if (!cartItem) return;
    cartItem.quantity = quantity;
  }

  getCart(): Cart {
    return this.cart;
  }

}
