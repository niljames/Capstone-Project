import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { SharedService } from 'src/app/shared.service';
import { adminCategory } from 'src/app/shared/models/adminCategory';

@Injectable({
  providedIn: 'root'
})
export class CategoryService {

  tempdata = new Array();

  constructor(private http: HttpClient, private shared: SharedService) { }
  getAll() {
    this.getData(0);
    return this.tempdata;

  }
  ngOnInit(): void {
    this.getData(0);
  }

  getData(i: number) {
    return this.http.get<any>(this.shared.MedicineCategoryURL).subscribe((data: any) => {
      data.forEach((element: adminCategory[]) => {
        this.tempdata[i++] = (element);
      });
    })
  }
}
