import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { SharedService } from 'src/app/shared.service';
import { adminModel } from 'src/app/shared/models/adminModel';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  tempdata = new Array();

  constructor(private http: HttpClient, private shared: SharedService) { }
  getAll() {
    this.getData(0);
    return this.tempdata;

  }
  ngOnInit(): void {
    this.getData(0);
  }

  getData(i: number) {
    return this.http.get<any>(this.shared.UserURL).subscribe((data: any) => {
      data.forEach((element: adminModel[]) => {
        this.tempdata[i++] = (element);
      });
    })
  }
}
