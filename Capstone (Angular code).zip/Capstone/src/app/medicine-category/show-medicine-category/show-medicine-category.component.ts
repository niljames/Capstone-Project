import { Component, OnInit } from '@angular/core';
import { SharedService } from 'src/app/shared.service';

@Component({
  selector: 'app-show-medicine-category',
  templateUrl: './show-medicine-category.component.html',
  styleUrls: ['./show-medicine-category.component.css']
})
export class ShowMedicineCategoryComponent implements OnInit {

  constructor(private service: SharedService) { }


  MedicineCategory: any = [];
  ngOnInit(): void {
    this.refreshList();
  }

  refreshList() {
    this.service.getMedicineCategoryList().subscribe(data => {
      this.MedicineCategory = data;
      console.log(this.MedicineCategory);
    })
  }
}
