import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowMedicineCategoryComponent } from './show-medicine-category.component';

describe('ShowMedicineCategoryComponent', () => {
  let component: ShowMedicineCategoryComponent;
  let fixture: ComponentFixture<ShowMedicineCategoryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ShowMedicineCategoryComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ShowMedicineCategoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
