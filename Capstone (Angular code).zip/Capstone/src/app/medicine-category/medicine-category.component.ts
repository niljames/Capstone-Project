import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-medicine-category',
  templateUrl: './medicine-category.component.html',
  styleUrls: ['./medicine-category.component.css']
})
export class MedicineCategoryComponent implements OnInit {

  constructor() { }


  ngOnInit(): void {

  }



}
