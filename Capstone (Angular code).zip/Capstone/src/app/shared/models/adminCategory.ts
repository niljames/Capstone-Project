export class adminCategory {
    medicineCategoryId!: number;
    category_Name!: string;
}