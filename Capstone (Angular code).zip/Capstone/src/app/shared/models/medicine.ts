export class Medicine {
    medicineId!: number;
    name!: string;
    image!: string;
    price!: number;
    category!: string;
    description!: string;
}