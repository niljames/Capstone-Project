export class adminMedicine {
    medicineId!: number;
    name!: string;
    image!: string;
    price!: number;
    category_Name!: string;
    description!: string;
}