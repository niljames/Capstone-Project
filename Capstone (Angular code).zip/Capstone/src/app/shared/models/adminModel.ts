export class adminModel {
    userId!: string;
    username!: string;
    password!: string;
    email!: string;
}