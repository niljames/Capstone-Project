import { Medicine } from "./medicine";

export class CartItem {
    constructor(medicine: Medicine) {
        this.medicine = medicine;
    }
    medicine: Medicine;
    quantity: number = 1;

    get Price(): number {
        return this.medicine.price * this.quantity;
    }
}
