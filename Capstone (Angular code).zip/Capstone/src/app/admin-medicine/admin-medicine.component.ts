import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { MedicineService } from '../services/medicine/medicine.service';
import { SharedService } from '../shared.service';
import { adminMedicine } from '../shared/models/adminMedicine';

@Component({
  selector: 'app-admin-medicine',
  templateUrl: './admin-medicine.component.html',
  styleUrls: ['./admin-medicine.component.css']
})
export class AdminMedicineComponent implements OnInit {

  formValue!: FormGroup;
  adminMedicineObj: adminMedicine = new adminMedicine();
  Medicine!: any;
  category!: any;
  showAdd!: boolean;
  showUpdate!: boolean;
  row_id!: number;
  MedicineData: adminMedicine[] = [];
  category_name: any;

  constructor(private formbuilder: FormBuilder, private shared: SharedService, private httpClient: HttpClient, private router: Router, private MedicineService: MedicineService) {
  }

  ngOnInit(): void {
    this.formValue = this.formbuilder.group({
      Name: [''],
      Image: [''],
      Price: 0,
      Description: [''],
      category_Name: ['']
    })
    this.getMedicineDetails();
    this.getCategoryDetails();
    this.MedicineData = this.MedicineService.getAll();
  }

  getCategoryDetails() {
    this.shared.getMedicineCategoryList().subscribe(res => {
      this.category = res;
    })
  }

  getMedicineDetails() {
    this.shared.getMedicineList().subscribe(res => {
      this.Medicine = res;
    })
  }

  back() {

    this.router.navigateByUrl('admin');

  }
  clickAddBtn() {
    this.formValue.reset();
    this.showAdd = true;
    this.showUpdate = false;
  }
  AddDetails() {
    this.adminMedicineObj.name = this.formValue.value.Name;
    this.adminMedicineObj.image = this.formValue.value.Image;
    this.adminMedicineObj.price = this.formValue.value.Price;
    this.adminMedicineObj.description = this.formValue.value.Description;
    this.adminMedicineObj.category_Name = this.formValue.value.category_Name;
    this.shared.addMedicine(this.adminMedicineObj).subscribe(res => {
      console.log(res);
      alert("New Category Added Successfully!");
      let ref = document.getElementById('cancel');
      ref?.click();
      this.formValue.reset();
      this.getMedicineDetails();
    },
      err => {
        alert("Something went wrong");
      })
  }
  deleteLogin(row: any) {
    this.shared.deleteMedicine(row.medicineId).subscribe(res => {
      alert("Category deleted!");
      this.getMedicineDetails();
    })
  }


  onEdit(row: any) {
    this.showAdd = false;
    this.showUpdate = true;
    this.row_id = row.medicineId;
    this.formValue.controls['Name'].setValue(row.name);
    this.formValue.controls['Image'].setValue(row.image);
    this.formValue.controls['Price'].setValue(row.price);
    this.formValue.controls['Description'].setValue(row.description);
    this.formValue.controls['category_Name'].setValue(row.category_Name);
  }


  updateLogin() {
    this.adminMedicineObj.medicineId = this.row_id;
    this.adminMedicineObj.name = this.formValue.value.Name;
    this.adminMedicineObj.image = this.formValue.value.Image;
    this.adminMedicineObj.price = this.formValue.value.Price;
    this.adminMedicineObj.description = this.formValue.value.Description;
    this.adminMedicineObj.category_Name = this.formValue.value.category_Name;
    this.shared.editMedicine(this.adminMedicineObj).subscribe(res => {
      alert("Update Done Successfully!");
      let ref = document.getElementById('cancel');
      ref?.click();
      this.formValue.reset();
      this.getMedicineDetails();
    })
  }

  tempdata = new Array();
  getData(i: number) {
    this.httpClient.get(this.shared.MedicineURL).subscribe((data: any) => {
      data.forEach((element: adminMedicine[]) => {
        this.tempdata[i++] = (element);
      });
    })

  }

}

