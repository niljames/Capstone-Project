import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { LoginService } from '../services/login/login.service';
import { SharedService } from '../shared.service';
import { adminModel } from '../shared/models/adminModel';

@Component({
  selector: 'app-admin-login',
  templateUrl: './admin-login.component.html',
  styleUrls: ['./admin-login.component.css']
})
export class AdminLoginComponent implements OnInit {

  formValue!: FormGroup;
  adminLoginObj: adminModel = new adminModel();
  adminLoginData!: any;
  adminData!: any;
  showAdd!: boolean;
  showUpdate!: boolean;
  login = new Array();
  row_id!: string;
  loginData: adminModel[] = [];

  constructor(private formbuilder: FormBuilder, private shared: SharedService, private httpClient: HttpClient, private router: Router, private loginService: LoginService) {
  }

  ngOnInit(): void {
    this.formValue = this.formbuilder.group({
      username: [''],
      email: [''],
      password: ['']
    })
    this.getLoginDetails();
    this.loginData = this.loginService.getAll();
  }

  getLoginDetails() {
    this.shared.getUserList().subscribe(res => {
      this.adminData = res;
    })
  }

  back() {

    this.router.navigateByUrl('admin');

  }
  clickAddBtn() {
    this.formValue.reset();
    this.showAdd = true;
    this.showUpdate = false;
  }
  AddDetails() {
    this.adminLoginObj.username = this.formValue.value.username;
    this.adminLoginObj.email = this.formValue.value.email;
    this.adminLoginObj.password = this.formValue.value.password;
    this.shared.addUserDetails(this.adminLoginObj).subscribe(res => {
      console.log(res);
      alert("New Account Added Successfully!");
      let ref = document.getElementById('cancel');
      ref?.click();
      this.formValue.reset();
      this.getLoginDetails();
    },
      err => {
        alert("Something went wrong");
      })
  }
  deleteLogin(row: any) {
    this.shared.deleteUserDetails(row.userId).subscribe(res => {
      alert("Login Details deleted!");
      this.getLoginDetails();
    })
  }


  onEdit(row: any) {
    this.showAdd = false;
    this.showUpdate = true;
    this.row_id = row.userId;
    console.log(row.userId);
    this.formValue.controls['username'].setValue(row.username);
    this.formValue.controls['email'].setValue(row.email);
    this.formValue.controls['password'].setValue(row.password);
  }


  updateLogin() {
    this.adminLoginObj.userId = this.row_id;
    this.adminLoginObj.username = this.formValue.value.username;
    this.adminLoginObj.email = this.formValue.value.email;
    this.adminLoginObj.password = this.formValue.value.password;
    console.log(this.adminLoginObj.userId);
    this.shared.editUserDetails(this.adminLoginObj).subscribe(res => {
      alert("Update Done Successfully!");
      let ref = document.getElementById('cancel');
      ref?.click();
      this.formValue.reset();
      this.getLoginDetails();
    })
  }

  tempdata = new Array();
  getData(i: number) {
    this.httpClient.get(this.shared.UserURL).subscribe((data: any) => {
      data.forEach((element: adminModel[]) => {
        this.tempdata[i++] = (element);
      });
    })

  }
}
