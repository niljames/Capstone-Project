import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { of } from 'rxjs/internal/observable/of';
import { CategoryService } from '../services/category/category.service';
import { SharedService } from '../shared.service';
import { adminCategory } from '../shared/models/adminCategory';

@Component({
  selector: 'app-admin-category',
  templateUrl: './admin-category.component.html',
  styleUrls: ['./admin-category.component.css']
})
export class AdminCategoryComponent implements OnInit {

  formValue!: FormGroup;
  adminLoginObj: adminCategory = new adminCategory();
  adminLoginData!: any;
  category!: any;
  showAdd!: boolean;
  showUpdate!: boolean;
  login = new Array();
  row_id!: number;
  loginData: adminCategory[] = [];

  constructor(private formbuilder: FormBuilder, private shared: SharedService, private httpClient: HttpClient, private router: Router, private CategoryService: CategoryService) {
  }

  ngOnInit(): void {
    this.formValue = this.formbuilder.group({
      category_Name: [''],
    })
    this.getLoginDetails();
    this.loginData = this.CategoryService.getAll();
  }



  getLoginDetails() {
    this.shared.getMedicineCategoryList().subscribe(res => {
      this.category = res;
    })
  }

  back() {

    this.router.navigateByUrl('admin');

  }
  clickAddBtn() {
    this.formValue.reset();
    this.showAdd = true;
    this.showUpdate = false;
  }
  AddDetails() {
    this.adminLoginObj.category_Name = this.formValue.value.category_Name;
    console.log(this.formValue.value.category_Name);
    this.shared.addMedicineCategory(this.adminLoginObj).subscribe(res => {
      console.log(res);
      alert("New Category Added Successfully!");
      let ref = document.getElementById('cancel');
      ref?.click();
      this.formValue.reset();
      this.getLoginDetails();
    },
      err => {
        alert("Something went wrong");
      })
  }
  deleteLogin(row: any) {
    this.shared.deleteMedicineCategory(row.medicineCategoryId).subscribe(res => {
      alert("Category deleted!");
      this.getLoginDetails();
    })
  }


  onEdit(row: any) {
    this.showAdd = false;
    this.showUpdate = true;
    this.row_id = row.medicineCategoryId;
    this.formValue.controls['category_Name'].setValue(row.category_Name);
  }


  updateLogin() {
    this.adminLoginObj.medicineCategoryId = this.row_id;
    this.adminLoginObj.category_Name = this.formValue.value.category_Name;
    this.shared.editMedicineCategory(this.adminLoginObj).subscribe(res => {
      alert("Update Done Successfully!");
      let ref = document.getElementById('cancel');
      ref?.click();
      this.formValue.reset();
      this.getLoginDetails();
    })
  }

  tempdata = new Array();
  getData(i: number) {
    this.httpClient.get(this.shared.UserURL).subscribe((data: any) => {
      data.forEach((element: adminCategory[]) => {
        this.tempdata[i++] = (element);
      });
    })

  }

}
