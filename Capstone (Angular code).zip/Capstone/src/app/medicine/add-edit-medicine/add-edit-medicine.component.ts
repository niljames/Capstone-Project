import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-edit-medicine',
  templateUrl: './add-edit-medicine.component.html',
  styleUrls: ['./add-edit-medicine.component.css']
})
export class AddEditMedicineComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
