import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { SharedService } from 'src/app/shared.service';
import { CartService } from 'src/app/services/cart/cart.service';

@Component({
  selector: 'app-show-medicine',
  templateUrl: './show-medicine.component.html',
  styleUrls: ['./show-medicine.component.css']
})
export class ShowMedicineComponent implements OnInit {

  Medicine: any = [];
  category: any;
  MedicineForModal: any = [];
  constructor(private activatedRoute: ActivatedRoute, private shared: SharedService, private router: Router, private cartService: CartService) {
    activatedRoute.params.subscribe((params) => {

      this.category = params.id;
    })
  }

  ngOnInit(): void {
    this.refreshList();
  }

  refreshList() {
    this.shared.getMedicineList().subscribe(data => {
      this.Medicine = data;
    })
  }

  getMedDetails(id: any) {
    this.shared.getMedicineDetails(id).subscribe(data => {
      this.MedicineForModal = data;
    })
  }

  addToCart(id: any) {
    this.shared.getMedicineDetails(id).subscribe(data => {
      this.cartService.addToCart(data);
    })

    this.router.navigateByUrl('Cart');
  }
}
