import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { CartService } from '../services/cart/cart.service';
import { LoginService } from '../services/login/login.service';
import { SharedService } from '../shared.service';
import { adminModel } from '../shared/models/adminModel';
import { Cart } from '../shared/models/cart';
import { timer } from 'rxjs';
import { take } from 'rxjs/operators';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  formValue!: FormGroup;
  searchTerm: String = "";
  adminLoginObj: adminModel = new adminModel();
  namechange: string = '';
  loginData: adminModel[] = [];
  adminData: any;
  checking: boolean = false;
  name: String = "";



  constructor(private route: ActivatedRoute, private router: Router, private cartService: CartService,
    private formbuilder: FormBuilder,
    private loginService: LoginService, private shared: SharedService) {
    this.setCart();

  }

  ngOnInit(): void {
    this.route.params.subscribe(params => {
      if (params.searchTerm)
        this.searchTerm = params.searchTerm;
    })
    this.formValue = this.formbuilder.group({
      id: 0,
      username: [''],
      email: [''],
      password: ['']
    })
    this.loginData = this.loginService.getAll();
  }

  search() {
    if (this.searchTerm)
      this.router.navigate(['Medicine' + this.searchTerm]);

  }
  cart!: Cart;


  setCart() {
    this.cart = this.cartService.getCart();
  }

  AddDetails() {
    this.adminLoginObj.username = this.formValue.value.username;
    this.adminLoginObj.password = this.formValue.value.password;
    this.adminLoginObj.email = this.formValue.value.email;
    this.shared.addUserDetails(this.adminLoginObj).subscribe(res => {
      console.log(res);
      alert("Account creation successful!");
      let ref = document.getElementById('cancel');
      ref?.click();
      this.formValue.reset();
      window.location.reload();
    },
      err => {
        alert("Something went wrong");
      })
  }


  CheckDetails() {
    this.loginData = this.loginService.getAll();
    const btn1 = <HTMLButtonElement>document.getElementById("login");
    const btn2 = <HTMLButtonElement>document.getElementById("logout");
    for (let i = 0; i < this.loginData.length; i++) {
      if (btn1.innerText == "Login" && this.formValue.value.email === "admin@gmail.com" && this.formValue.value.password === "admin") {
        alert("Admin Login successful!");
        this.router.navigateByUrl('admin');
        let ref = document.getElementById('cancel');
        ref?.click();
        const txt = "Welcome Admin";
        this.formValue.reset();
        this.namechange = txt;
        btn1.style.display = "none";
        btn2.style.display = "block";
        localStorage.setItem('isLoggedIn', 'true');
        this.checking = true;
        return;

      }
      else if (btn1.innerText == "Login" && this.loginData[i].email === this.formValue.value.email && this.loginData[i].password === this.formValue.value.password) {
        console.log(this.loginData)
        alert("Login successful!");
        let ref = document.getElementById('cancel');
        ref?.click();
        const txt = "Welcome " + this.loginData[i].username;
        this.formValue.reset();
        this.router.navigateByUrl('');
        this.namechange = txt;
        btn1.style.display = "none";
        btn2.style.display = "block";
        this.checking = true;
        return;
      }
    }
    alert("Invalid Details");
    this.checking = false;
    return;

  }

  async check() {
    const btn1 = <HTMLButtonElement>document.getElementById("login");
    const btn2 = <HTMLButtonElement>document.getElementById("logout");
    btn2.style.display = "none";
    btn1.style.display = "block";
    alert("Succesfully Logged Out!");
    this.router.navigate(['home']);
    this.namechange = '';
    localStorage.removeItem('isLoggedIn');

  }


  checkingLogin() {
    if (this.checking == false) {
      alert("Please Login");
      this.router.navigate(['home']);
    }
  }

}
