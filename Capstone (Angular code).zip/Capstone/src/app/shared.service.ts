import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { adminModel } from './shared/models/adminModel';
@Injectable({
  providedIn: 'root'
})
export class SharedService {
  readonly MedicineURL = "http://localhost:39636/api/Medicine";
  readonly MedicineCategoryURL = "http://localhost:39636/api/MedicineCategory"
  UserURL: string = "http://localhost:39636/api/User";

  constructor(private http: HttpClient) { }

  getMedicineCategoryList(): Observable<any[]> {
    return this.http.get<any>(this.MedicineCategoryURL);
  }

  getMedicineCategoryDetails(id: any) {
    return this.http.get<any>(this.MedicineCategoryURL + "/" + id);
  }

  addMedicineCategory(val: any) {
    return this.http.post<any>(this.MedicineCategoryURL + "/addCategory", val);
  }

  editMedicineCategory(val: any) {
    return this.http.put<any>(this.MedicineCategoryURL + "/updateCategory", val);
  }

  deleteMedicineCategory(id: number) {
    return this.http.delete<any>(this.MedicineCategoryURL + "/deleteCategory/" + id);
  }

  getMedicineList(): Observable<any[]> {
    return this.http.get<any>(this.MedicineURL);
  }

  getMedicineDetails(id: any) {
    return this.http.get<any>(this.MedicineURL + "/" + id);
  }

  addMedicine(val: any) {
    return this.http.post<any>(this.MedicineURL + "/addMedicine", val);
  }

  editMedicine(val: any) {
    return this.http.put<any>(this.MedicineURL + "/updateMedicine", val);
  }

  deleteMedicine(id: number) {
    return this.http.delete<any>(this.MedicineURL + "/deleteMedicine/" + id);
  }



  getUserList(): Observable<any[]> {
    return this.http.get<any>(this.UserURL);
  }

  getUserDetails(id: any) {
    return this.http.get<any>(this.UserURL + "/" + id);
  }
  addUserDetails(val: any) {
    return this.http.post<any>(this.UserURL + "/addUser", val);
  }
  editUserDetails(val: any) {
    return this.http.put(this.UserURL + '/updateUser', val);
  }

  deleteUserDetails(id: any) {
    return this.http.delete<any>(this.UserURL + "/deleteUser/" + id);
  }

}
