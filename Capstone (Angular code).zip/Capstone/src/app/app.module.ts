import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MedicineCategoryComponent } from './medicine-category/medicine-category.component';
import { MedicineComponent } from './medicine/medicine.component';
import { SharedService } from './shared.service';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ShowMedicineCategoryComponent } from './medicine-category/show-medicine-category/show-medicine-category.component';
import { ShowMedicineComponent } from './medicine/show-medicine/show-medicine.component';
import { CartPageComponent } from './cart-page/cart-page.component';
import { HeaderComponent } from './header/header.component';
import { AdminLoginComponent } from './admin-login/admin-login.component';
import { AdminCategoryComponent } from './admin-category/admin-category.component';
import { AdminMedicineComponent } from './admin-medicine/admin-medicine.component';
import { HomeComponent } from './home/home.component';
import { AdminMainPageComponent } from './admin-main-page/admin-main-page.component';
@NgModule({
  declarations: [
    AppComponent,
    MedicineCategoryComponent,
    MedicineComponent,
    ShowMedicineCategoryComponent,
    ShowMedicineComponent,
    CartPageComponent,
    HeaderComponent,
    AdminLoginComponent,
    AdminCategoryComponent,
    AdminMedicineComponent,
    HomeComponent,
    AdminMainPageComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [SharedService],
  bootstrap: [AppComponent]
})
export class AppModule { }
