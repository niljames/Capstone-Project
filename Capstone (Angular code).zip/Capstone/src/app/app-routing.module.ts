import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MedicineComponent } from './medicine/medicine.component';
import { MedicineCategoryComponent } from './medicine-category/medicine-category.component';
import { CartPageComponent } from './cart-page/cart-page.component';
import { AdminLoginComponent } from './admin-login/admin-login.component';
import { AdminCategoryComponent } from './admin-category/admin-category.component';
import { AdminMedicineComponent } from './admin-medicine/admin-medicine.component';
import { HomeComponent } from './home/home.component';
import { AdminMainPageComponent } from './admin-main-page/admin-main-page.component';
const routes: Routes = [
  { path: "Medicine", component: MedicineComponent },
  { path: "MedicineCategory", component: MedicineCategoryComponent },
  { path: 'Medicine/:id', component: MedicineComponent },
  { path: 'Cart', component: CartPageComponent },
  { path: 'admin-login', component: AdminLoginComponent },
  { path: 'admin-category', component: AdminCategoryComponent },
  { path: 'admin-medicine', component: AdminMedicineComponent },
  { path: 'home', component: HomeComponent },
  { path: 'admin', component: AdminMainPageComponent },
  { path: '**', redirectTo: 'home', pathMatch: 'full' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
