﻿using System;
using System.Collections.Generic;

namespace Capstone_API.Models
{
    public partial class MedicineCategory
    {
        public int MedicineCategoryId { get; set; }
        public string Category_Name { get; set; }
    }
}
